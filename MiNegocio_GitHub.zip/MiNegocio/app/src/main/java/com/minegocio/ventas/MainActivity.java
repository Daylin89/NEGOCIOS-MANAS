package com.minegocio.ventas;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0F766E, PRI2 = 0xFF0D9488, BG = 0xFFF2F7F6, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A, ORG = 0xFFEA580C,
            BLU = 0xFF2563EB, PUR = 0xFF7C3AED;
    static final Locale ES = new Locale("es");
    static final String[] METHODS = {"Efectivo", "Transferencia", "Otro"};
    static final int REQ_EXPORT = 81, REQ_PHOTO = 82, REQ_PICK = 83;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int NUM = InputType.TYPE_CLASS_NUMBER;
    static final int DEC = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

    interface Cb { void on(String s); }

    List<JSONObject> products, purchases, sales, expenses, transfers;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String period = "Este mes", search = "", salesFilter = "Todas";
    int pendingProduct = -1;
    Uri pendingUri;

    // ============================ Datos ============================
    SharedPreferences sp() { return getSharedPreferences("negocio", Context.MODE_PRIVATE); }

    List<JSONObject> load(String k) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp().getString(k, "[]"));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    void save(String k, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp().edit().putString(k, a.toString()).apply();
    }

    void saveAll() {
        save("products", products);
        save("purchases", purchases);
        save("sales", sales);
        save("expenses", expenses);
        save("transfers", transfers);
    }

    int nextId() {
        int n = sp().getInt("nextId", 1);
        sp().edit().putInt("nextId", n + 1).apply();
        return n;
    }

    String pref(String k, String d) { return sp().getString(k, d); }
    void setPref(String k, String v) { sp().edit().putString(k, v).apply(); }
    String biz() { return pref("biz", "Mi Negocio"); }
    String partner(String who) { return who.equals("2") ? pref("p2", "Socia") : pref("p1", "Daylin"); }
    String cur() { return pref("cur", "$"); }

    String money(double v) {
        String s = String.format(Locale.US, "%,.2f", Math.abs(v));
        if (s.endsWith(".00")) s = s.substring(0, s.length() - 3);
        return (v < -0.004 ? "-" : "") + cur() + s;
    }

    static String qty(double q) {
        if (Math.abs(q - Math.round(q)) < 0.0001) return String.valueOf(Math.round(q));
        return String.format(Locale.US, "%.2f", q);
    }

    static double num(String s) {
        try { return Double.parseDouble(s.trim().replace(",", ".").replace("$", "")); } catch (Exception e) { return 0; }
    }

    // ---- cálculos por producto ----
    double bought(int pid) { double q = 0; for (JSONObject x : purchases) if (x.optInt("pid") == pid) q += x.optDouble("qty", 0); return q; }
    double boughtCost(int pid) { double c = 0; for (JSONObject x : purchases) if (x.optInt("pid") == pid) c += x.optDouble("qty", 0) * x.optDouble("cost", 0); return c; }
    double sold(int pid) { double q = 0; for (JSONObject x : sales) if (x.optInt("pid") == pid) q += x.optDouble("qty", 0); return q; }
    double stock(int pid) { return bought(pid) - sold(pid); }
    double avgCost(int pid) { double q = bought(pid); return q <= 0 ? 0 : boughtCost(pid) / q; }
    double soldAmount(int pid) { double t = 0; for (JSONObject x : sales) if (x.optInt("pid") == pid) t += saleTotal(x); return t; }
    double soldProfit(int pid) { double t = 0; for (JSONObject x : sales) if (x.optInt("pid") == pid) t += saleProfit(x); return t; }
    static double saleTotal(JSONObject s) { return s.optDouble("qty", 0) * s.optDouble("price", 0); }
    static double saleProfit(JSONObject s) { return s.optDouble("qty", 0) * (s.optDouble("price", 0) - s.optDouble("cost", 0)); }

    JSONObject product(int id) { for (JSONObject p : products) if (p.optInt("id") == id) return p; return null; }

    long[] range() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (period.equals("Hoy")) { long a = c.getTimeInMillis(); return new long[]{a, a + 86400000L}; }
        c.set(Calendar.DAY_OF_MONTH, 1);
        if (period.equals("Este mes")) { long a = c.getTimeInMillis(); c.add(Calendar.MONTH, 1); return new long[]{a, c.getTimeInMillis()}; }
        if (period.equals("Mes pasado")) { long b = c.getTimeInMillis(); c.add(Calendar.MONTH, -1); return new long[]{c.getTimeInMillis(), b}; }
        return new long[]{0, Long.MAX_VALUE};
    }

    static boolean in(JSONObject o, long[] r) { long d = o.optLong("date"); return d >= r[0] && d < r[1]; }

    // ---- cuentas entre socias (todo el tiempo, en efectivo) ----
    double put(String who) {
        double t = 0;
        for (JSONObject x : purchases) if (x.optString("by").equals(who)) t += x.optDouble("qty", 0) * x.optDouble("cost", 0);
        for (JSONObject x : expenses) if (x.optString("by").equals(who)) t += x.optDouble("amount", 0);
        return t;
    }

    double collected(String who) {
        double t = 0;
        for (JSONObject x : sales) if (x.optBoolean("paid") && x.optString("by").equals(who)) t += saleTotal(x);
        return t;
    }

    double transferNet(String who) {
        double t = 0;
        for (JSONObject x : transfers) {
            if (x.optString("to").equals(who)) t += x.optDouble("amount", 0);
            if (x.optString("from").equals(who)) t -= x.optDouble("amount", 0);
        }
        return t;
    }

    double cashNet(String who) { return collected(who) - put(who) + transferNet(who); }

    // =====================================================================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        products = load("products");
        purchases = load("purchases");
        sales = load("sales");
        expenses = load("expenses");
        transfers = load("transfers");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        fab = tv("", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);
        setContentView(root);
        Backup.autoBackup(this);
        if (!sp().getBoolean("setup", false)) { tabSel = 4; stack.clear(); open(() -> settings(true)); }
        else openTab(0);
    }

    // ============================ Navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::home);
        else if (k == 1) open(this::productsScreen);
        else if (k == 2) open(this::salesScreen);
        else if (k == 3) open(this::partnersScreen);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) { stack.remove(stack.size() - 1); stack.get(stack.size() - 1).run(); }
        else if (tabSel != 0) openTab(0);
        else finish();
    }

    void refresh() { if (!stack.isEmpty()) stack.get(stack.size() - 1).run(); }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        TextView tt = tv(title, 20, Color.WHITE, true);
        tt.setMaxLines(1);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(tt);
        if (sub != null) t.addView(tv(sub, 13, 0xFFCCFBF1, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, String fabText, Runnable fabAction) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        if (fabText != null) {
            fab.setText(fabText);
            fab.setOnClickListener(v -> fabAction.run());
            fab.setVisibility(View.VISIBLE);
        } else fab.setVisibility(View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"🏠", "Inicio"}, {"📦", "Productos"}, {"💰", "Ventas"}, {"🤝", "Socias"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFDDF4F1, 12) : null);
        }
    }

    // ============================ Inicio ============================
    void home() {
        setHeader(biz(), "Socias: " + partner("1") + " y " + partner("2"), "🛍️", false);
        LinearLayout p = vbox();
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(8), dp(10), 0);
        for (String o : new String[]{"Hoy", "Este mes", "Mes pasado", "Todo"})
            chips.addView(chip(o, o.equals(period), v -> { period = o; home(); }));
        p.addView(hscroll(chips));

        long[] r = range();
        double revenue = 0, profitSales = 0, exp = 0, pending = 0, units = 0;
        for (JSONObject s : sales) if (in(s, r)) {
            revenue += saleTotal(s);
            profitSales += saleProfit(s);
            units += s.optDouble("qty", 0);
        }
        for (JSONObject e : expenses) if (in(e, r)) exp += e.optDouble("amount", 0);
        for (JSONObject s : sales) if (!s.optBoolean("paid")) pending += saleTotal(s);
        double profit = profitSales - exp;

        LinearLayout big = card();
        big.setBackground(round(PRI, 18));
        big.addView(tv("Ganancia · " + period.toLowerCase(ES), 14, 0xFFCCFBF1, true));
        big.addView(tv(money(profit), 32, Color.WHITE, true));
        LinearLayout split = hbox();
        split.setPadding(0, dp(8), 0, 0);
        split.addView(halfBox(partner("1"), money(profit / 2)), weightLp(1f));
        split.addView(halfBox(partner("2"), money(profit / 2)), weightLp(1f));
        big.addView(split);
        if (exp > 0) {
            TextView ex = tv("Ventas " + money(profitSales) + " de ganancia − gastos " + money(exp), 12, 0xFFCCFBF1, false);
            ex.setPadding(0, dp(8), 0, 0);
            big.addView(ex);
        }
        p.addView(big);

        LinearLayout row = hbox();
        row.setPadding(dp(10), 0, dp(10), 0);
        row.addView(stat("💰", money(revenue), "Vendido", PRI2, 0xFFDDF4F1));
        row.addView(stat("🛒", qty(units), "Unidades", BLU, 0xFFE4ECFF));
        row.addView(stat("🧾", money(pending), "Por cobrar", ORG, 0xFFFFEDD5));
        p.addView(row);

        double stockUnits = 0, stockValue = 0, stockPotential = 0;
        List<JSONObject> low = new ArrayList<>();
        for (JSONObject pr : products) {
            int id = pr.optInt("id");
            double st = stock(id), ac = avgCost(id);
            stockUnits += Math.max(0, st);
            stockValue += Math.max(0, st) * ac;
            stockPotential += Math.max(0, st) * (pr.optDouble("price", 0) - ac);
            if (st <= pr.optDouble("min", 0) && bought(id) > 0) low.add(pr);
        }
        p.addView(sectionTitle("📦 Inventario", "Ver productos ›", v -> openTab(1)));
        LinearLayout inv = card();
        inv.addView(kv("Unidades en existencia", qty(stockUnits)));
        inv.addView(kv("Invertido en lo que queda", money(stockValue)));
        inv.addView(kv("Ganancia si se vende todo", money(stockPotential), GRN));
        inv.addView(kv("Cada una ganaría", money(stockPotential / 2), GRN));
        p.addView(inv);

        LinearLayout qa = hbox();
        qa.setPadding(dp(10), dp(6), dp(10), 0);
        qa.addView(action("💰", "Vender", GRN, 0xFFE3F6E8, v -> open(() -> saleForm(-1))));
        qa.addView(action("🛒", "Comprar", BLU, 0xFFE4ECFF, v -> pickProduct(id -> open(() -> purchaseForm(Integer.parseInt(id))))));
        qa.addView(action("💸", "Gasto", ORG, 0xFFFFEDD5, v -> open(() -> expenseForm())));
        qa.addView(action("📲", "Catálogo", PUR, 0xFFF0E9FF, v -> shareCatalog()));
        p.addView(qa);

        if (!low.isEmpty()) {
            p.addView(sectionTitle("⚠️ Se están acabando", null, null));
            for (JSONObject pr : low) p.addView(productRow(pr));
        }

        Map<Integer, Double> top = new HashMap<>();
        for (JSONObject s : sales) if (in(s, r)) top.put(s.optInt("pid"), top.getOrDefault(s.optInt("pid"), 0.0) + s.optDouble("qty", 0));
        if (!top.isEmpty()) {
            List<Map.Entry<Integer, Double>> ent = new ArrayList<>(top.entrySet());
            Collections.sort(ent, (a, b) -> Double.compare(b.getValue(), a.getValue()));
            p.addView(sectionTitle("🏆 Lo más vendido", null, null));
            LinearLayout tc = card();
            for (int i = 0; i < ent.size() && i < 5; i++) {
                JSONObject pr = product(ent.get(i).getKey());
                tc.addView(kv((i + 1) + ". " + (pr == null ? "Producto eliminado" : pr.optString("name")), qty(ent.get(i).getValue()) + " vendidos"));
            }
            p.addView(tc);
        }
        if (products.isEmpty()) p.addView(empty("Empieza agregando tus productos en la pestaña 📦 Productos."));
        show(scroll(p), true, "＋  Venta", () -> open(() -> saleForm(-1)));
    }

    View halfBox(String name, String value) {
        LinearLayout b = vbox();
        b.setBackground(round(0x33FFFFFF, 12));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.addView(tv("👤 " + name, 13, 0xFFCCFBF1, true));
        b.addView(tv(value, 18, Color.WHITE, true));
        return b;
    }

    View stat(String ic, String value, String label, int fg, int bg) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(4), dp(10), dp(4), dp(10));
        TextView i = tv(ic, 16, fg, false);
        TextView n = tv(value, 16, fg, true);
        TextView l = tv(label, 11, fg, false);
        i.setGravity(Gravity.CENTER);
        n.setGravity(Gravity.CENTER);
        n.setMaxLines(1);
        l.setGravity(Gravity.CENTER);
        b.addView(i);
        b.addView(n);
        b.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), dp(8), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    View kv(String k, String v) { return kv(k, v, TXT); }

    View kv(String k, String v, int color) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(4), 0, dp(4));
        r.addView(tv(k, 14, MUT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(tv(v, 15, color, true));
        return r;
    }

    // ============================ Productos ============================
    void productsScreen() {
        setHeader("Productos", products.size() + " productos", "📦", false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar producto o categoría", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = search.trim().toLowerCase(ES);
            List<JSONObject> r = new ArrayList<>();
            for (JSONObject pr : products)
                if (q.isEmpty() || (pr.optString("name") + " " + pr.optString("cat")).toLowerCase(ES).contains(q)) r.add(pr);
            Collections.sort(r, (a, b) -> a.optString("name").compareToIgnoreCase(b.optString("name")));
            if (products.isEmpty()) list.addView(empty("Todavía no hay productos.\nToca «＋ Producto» para agregar el primero."));
            else if (r.isEmpty()) list.addView(empty("No se encontraron productos"));
            for (JSONObject pr : r) list.addView(productRow(pr));
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, "＋  Producto", () -> open(() -> productForm(-1)));
    }

    View thumb(JSONObject pr, int size) {
        FrameLayout th = new FrameLayout(this);
        th.setBackground(round(0xFFDDF4F1, 12));
        th.setClipToOutline(true);
        TextView ph = tv("🛍️", size / 2.6f, PRI2, false);
        ph.setGravity(Gravity.CENTER);
        th.addView(ph, new FrameLayout.LayoutParams(-1, -1));
        if (!pr.optString("photo").isEmpty()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            loadThumb(iv, Uri.parse(pr.optString("photo")));
        }
        th.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return th;
    }

    View productRow(JSONObject pr) {
        int id = pr.optInt("id");
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(thumb(pr, 60));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, dp(4), 0);
        TextView nm = tv(pr.optString("name"), 16, TXT, true);
        nm.setMaxLines(2);
        r.addView(nm);
        double ac = avgCost(id), price = pr.optDouble("price", 0);
        r.addView(tv("Costo " + money(ac) + " → Venta " + money(price), 13, MUT, false));
        double st = stock(id);
        boolean lowS = st <= pr.optDouble("min", 0);
        LinearLayout pl = hbox();
        pl.setPadding(0, dp(4), 0, 0);
        TextView a = tv((st <= 0 ? "❌ Agotado" : "📦 Quedan " + qty(st)), 12, lowS ? RED : PRI, true);
        a.setBackground(round(lowS ? 0xFFFDE6E6 : 0xFFDDF4F1, 20));
        a.setPadding(dp(9), dp(3), dp(9), dp(3));
        pl.addView(a);
        TextView sd = tv("  ✅ Vendidos " + qty(sold(id)), 12, MUT, true);
        pl.addView(sd);
        r.addView(pl);
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = vbox();
        g.setGravity(Gravity.END);
        g.addView(tv("+" + money(price - ac), 15, GRN, true));
        g.addView(tv("por unidad", 11, MUT, false));
        c.addView(g);
        c.setOnClickListener(v -> open(() -> productDetail(id)));
        return c;
    }

    void productDetail(int id) {
        final JSONObject pr = product(id);
        if (pr == null) { goBack(); return; }
        setHeader(pr.optString("name"), pr.optString("cat").isEmpty() ? null : pr.optString("cat"), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        LinearLayout top = hbox();
        View th = thumb(pr, 84);
        th.setOnClickListener(v -> photoMenu(id));
        top.addView(th);
        LinearLayout nv = vbox();
        nv.setPadding(dp(14), 0, 0, 0);
        nv.addView(tv(pr.optString("name"), 18, TXT, true));
        double st = stock(id);
        nv.addView(tv(st <= 0 ? "❌ Agotado" : "📦 Quedan " + qty(st), 16, st <= pr.optDouble("min", 0) ? RED : PRI, true));
        nv.addView(tv("✅ Vendidos " + qty(sold(id)) + " de " + qty(bought(id)) + " comprados", 13, MUT, false));
        TextView ph = tv(pr.optString("photo").isEmpty() ? "📷 Agregar foto" : "📷 Cambiar foto", 13, PRI2, true);
        ph.setPadding(0, dp(4), 0, 0);
        ph.setOnClickListener(v -> photoMenu(id));
        nv.addView(ph);
        top.addView(nv, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(top);
        c.addView(divider());
        double ac = avgCost(id), price = pr.optDouble("price", 0);
        c.addView(kv("Costo promedio por unidad", money(ac)));
        c.addView(kv("Precio de venta", money(price)));
        c.addView(kv("Ganancia por unidad", money(price - ac) + (price > 0 ? "  (" + Math.round((price - ac) * 100 / price) + "%)" : ""), GRN));
        c.addView(kv("Cada socia por unidad", money((price - ac) / 2), GRN));
        c.addView(divider());
        c.addView(kv("Total vendido", money(soldAmount(id))));
        c.addView(kv("Ganancia obtenida", money(soldProfit(id)), GRN));
        c.addView(kv("Ganancia si se vende lo que queda", money(Math.max(0, st) * (price - ac)), GRN));
        if (!pr.optString("notes").isEmpty()) { c.addView(divider()); c.addView(tv("📝 " + pr.optString("notes"), 14, TXT, false)); }
        p.addView(c);

        LinearLayout b = hbox();
        b.setPadding(dp(8), dp(6), dp(8), 0);
        b.addView(button2("💰  Vender", GRN, v -> open(() -> saleForm(id))), weightLp(1f));
        b.addView(button2("🛒  Comprar más", BLU, v -> open(() -> purchaseForm(id))), weightLp(1f));
        p.addView(b);

        List<JSONObject> moves = new ArrayList<>();
        for (JSONObject x : purchases) if (x.optInt("pid") == id) moves.add(x);
        for (JSONObject x : sales) if (x.optInt("pid") == id) moves.add(x);
        Collections.sort(moves, (x, y) -> Long.compare(y.optLong("date"), x.optLong("date")));
        p.addView(sectionTitle("Movimientos", null, null));
        if (moves.isEmpty()) p.addView(empty("Sin compras ni ventas todavía"));
        for (int i = 0; i < moves.size() && i < 60; i++) {
            JSONObject m = moves.get(i);
            p.addView(m.has("price") ? saleRow(m, false) : purchaseRow(m));
        }

        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("✏️  Editar producto", PRI2, v -> open(() -> productForm(id))), weightLp(1.6f));
        btns.addView(outline("🗑️", RED, v -> new AlertDialog.Builder(this)
                .setTitle("Eliminar " + pr.optString("name"))
                .setMessage("Se borran también sus compras y ventas. ¿Seguro?")
                .setPositiveButton("Eliminar", (dlg, w) -> {
                    products.remove(pr);
                    removeWhere(purchases, id);
                    removeWhere(sales, id);
                    saveAll();
                    goBack();
                }).setNegativeButton("Cancelar", null).show()), weightLp(0.5f));
        p.addView(btns);
        show(scroll(p), false, null, null);
    }

    static void removeWhere(List<JSONObject> l, int pid) {
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).optInt("pid") == pid) l.remove(i);
    }

    void productForm(int id) {
        final JSONObject old = id < 0 ? null : product(id);
        setHeader(old == null ? "Nuevo producto" : "Editar producto", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText name = input("Ej. Perfume Carolina Herrera 100 ml", TXT_CAP);
        EditText cat = input("Ej. Perfumes (opcional)", TXT_CAP);
        EditText price = input("Precio de venta por unidad", DEC);
        EditText min = input("Ej. 2", NUM);
        EditText notes = input("Notas (opcional)", TXT_MULTI);
        EditText qtyF = input("Ej. 10", DEC);
        EditText costF = input("Costo por unidad", DEC);
        final String[] by = {"1"};
        if (old != null) {
            name.setText(old.optString("name"));
            cat.setText(old.optString("cat"));
            price.setText(qty(old.optDouble("price", 0)));
            min.setText(qty(old.optDouble("min", 0)));
            notes.setText(old.optString("notes"));
        }
        c.addView(label("🛍️", "Nombre del producto", true));
        c.addView(name);
        c.addView(label("🏷️", "Categoría", false));
        c.addView(cat);
        List<String> cats = new ArrayList<>();
        for (JSONObject x : products) { String k = x.optString("cat"); if (!k.isEmpty() && !cats.contains(k)) cats.add(k); }
        if (!cats.isEmpty()) {
            LinearLayout cc = hbox();
            for (String k : cats) cc.addView(chip(k, false, v -> cat.setText(k)));
            c.addView(hscroll(cc));
        }
        c.addView(twoCols(labeled("Precio de venta (" + cur() + ")", price), labeled("Avisar cuando queden", min)));
        final TextView preview = tv("", 14, GRN, true);
        preview.setPadding(0, dp(10), 0, 0);
        if (old == null) {
            LinearLayout pc = card();
            pc.addView(tv("🛒  Primera compra (opcional)", 16, TXT, true));
            pc.addView(tv("Cuántos compraron y cuánto costó cada uno. Después puedes agregar más compras.", 13, MUT, false));
            pc.addView(twoCols(labeled("Cantidad", qtyF), labeled("Costo por unidad (" + cur() + ")", costF)));
            pc.addView(preview);
            p.addView(pc);
            Runnable calc = () -> {
                double q = num(qtyF.getText().toString()), cs = num(costF.getText().toString()), pv = num(price.getText().toString());
                if (q > 0 && cs > 0) preview.setText("Inversión " + money(q * cs) + " (cada una " + money(q * cs / 2) + ")" + (pv > 0 ? " · Ganancia si se vende todo " + money(q * (pv - cs)) + " (cada una " + money(q * (pv - cs) / 2) + ")" : ""));
                else preview.setText("");
            };
            watch(qtyF, calc);
            watch(costF, calc);
            watch(price, calc);
        }
        c.addView(label("📝", "Notas", false));
        c.addView(notes);

        p.addView(button("Guardar producto", PRI2, v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { toast("Escribe el nombre del producto"); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) put(o, "id", nextId());
            put(o, "name", n);
            put(o, "cat", cat.getText().toString().trim());
            put(o, "price", num(price.getText().toString()));
            put(o, "min", num(min.getText().toString()));
            put(o, "notes", notes.getText().toString().trim());
            if (old == null) {
                products.add(o);
                double q = num(qtyF.getText().toString());
                if (q > 0) {
                    JSONObject b = new JSONObject();
                    put(b, "id", nextId());
                    put(b, "pid", o.optInt("id"));
                    put(b, "qty", q);
                    put(b, "cost", num(costF.getText().toString()));
                    put(b, "by", by[0]);
                    put(b, "date", System.currentTimeMillis());
                    purchases.add(b);
                }
            }
            saveAll();
            toast("Producto guardado ✅");
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    View partnerChips(String[] by) {
        LinearLayout r = hbox();
        final TextView a = chip("👤 " + partner("1"), by[0].equals("1"), null);
        final TextView b = chip("👤 " + partner("2"), by[0].equals("2"), null);
        a.setOnClickListener(v -> { by[0] = "1"; styleChip(a, true); styleChip(b, false); });
        b.setOnClickListener(v -> { by[0] = "2"; styleChip(a, false); styleChip(b, true); });
        r.addView(a);
        r.addView(b);
        return r;
    }

    void watch(EditText e, Runnable r) {
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable ed) { r.run(); }
        });
    }

    void pickProduct(Cb cb) {
        if (products.isEmpty()) { toast("Primero agrega un producto"); return; }
        List<JSONObject> l = new ArrayList<>(products);
        Collections.sort(l, (a, b) -> a.optString("name").compareToIgnoreCase(b.optString("name")));
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++)
            names[i] = l.get(i).optString("name") + "  (quedan " + qty(stock(l.get(i).optInt("id"))) + ")";
        new AlertDialog.Builder(this).setTitle("Elige el producto")
                .setItems(names, (dlg, w) -> cb.on(String.valueOf(l.get(w).optInt("id")))).show();
    }

    // ============================ Compras ============================
    void purchaseForm(int pid) {
        final JSONObject pr = product(pid);
        if (pr == null) { goBack(); return; }
        setHeader("Comprar", pr.optString("name"), null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText q = input("Ej. 10", DEC);
        EditText cost = input("Costo por unidad", DEC);
        EditText total = input("o el total pagado", DEC);
        EditText supplier = input("Ej. Tienda / proveedor (opcional)", TXT_CAP);
        double ac = avgCost(pid);
        if (ac > 0) cost.setText(qty(Math.round(ac * 100) / 100.0));
        final String[] by = {"1"};
        final long[] date = {System.currentTimeMillis()};
        c.addView(twoCols(labeled("Cantidad", q), labeled("Costo por unidad (" + cur() + ")", cost)));
        c.addView(labeled("Total pagado (" + cur() + ") — opcional, calcula el costo por unidad", total));
        c.addView(label("🏪", "Proveedor", false));
        c.addView(supplier);
        c.addView(dateField(date));
        final TextView preview = tv("", 14, GRN, true);
        preview.setPadding(0, dp(12), 0, 0);
        c.addView(preview);
        Runnable calc = () -> {
            double qq = num(q.getText().toString()), cs = num(cost.getText().toString()), tt = num(total.getText().toString());
            if (qq > 0 && tt > 0) cs = tt / qq;
            double pv = pr.optDouble("price", 0);
            if (qq > 0 && cs > 0) preview.setText("Inversión " + money(qq * cs) + " (cada una pone " + money(qq * cs / 2) + ") · costo " + money(cs) + " c/u"
                    + (pv > 0 ? "\nGanancia si se vende todo: " + money(qq * (pv - cs)) + " (cada una " + money(qq * (pv - cs) / 2) + ")" : ""));
            else preview.setText("");
        };
        watch(q, calc);
        watch(cost, calc);
        watch(total, calc);
        p.addView(button("🛒  Guardar compra", BLU, v -> {
            double qq = num(q.getText().toString()), cs = num(cost.getText().toString()), tt = num(total.getText().toString());
            if (qq <= 0) { toast("Escribe la cantidad"); return; }
            if (tt > 0) cs = tt / qq;
            if (cs <= 0) { toast("Escribe el costo por unidad o el total"); return; }
            JSONObject o = new JSONObject();
            put(o, "id", nextId());
            put(o, "pid", pid);
            put(o, "qty", qq);
            put(o, "cost", cs);
            put(o, "by", by[0]);
            put(o, "supplier", supplier.getText().toString().trim());
            put(o, "date", date[0]);
            purchases.add(o);
            saveAll();
            toast("Compra guardada · quedan " + qty(stock(pid)));
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    View purchaseRow(JSONObject x) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        TextView ic = tv("🛒", 20, BLU, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(0xFFE4ECFF, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, 0, 0);
        r.addView(tv("Compra de " + qty(x.optDouble("qty", 0)) + " × " + money(x.optDouble("cost", 0)), 15, TXT, true));
        r.addView(tv(join(" · ", dateStr(x.optLong("date")), "cada una " + money(x.optDouble("qty", 0) * x.optDouble("cost", 0) / 2), x.optString("supplier")), 13, MUT, false));
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv(money(x.optDouble("qty", 0) * x.optDouble("cost", 0)), 15, BLU, true));
        c.setOnLongClickListener(v -> { confirmDelete("esta compra", () -> purchases.remove(x)); return true; });
        return c;
    }

    // ============================ Ventas ============================
    void saleForm(int pidStart) {
        final int[] pid = {pidStart};
        if (pid[0] < 0 && products.size() == 1) pid[0] = products.get(0).optInt("id");
        setHeader("Nueva venta", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        final TextView prodF = field("Elige el producto  ▾");
        EditText q = input("1", DEC);
        q.setText("1");
        EditText price = input("Precio por unidad", DEC);
        EditText client = input("Nombre del cliente (opcional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        final String[] by = {"1"};
        final boolean[] paid = {true};
        final String[] method = {METHODS[0]};
        final long[] date = {System.currentTimeMillis()};
        final TextView info = tv("", 13, MUT, false);
        final TextView preview = tv("", 15, GRN, true);
        preview.setPadding(0, dp(12), 0, 0);
        final Runnable setProd = () -> {
            JSONObject pr = product(pid[0]);
            if (pr == null) return;
            prodF.setText("🛍️  " + pr.optString("name") + "  ▾");
            price.setText(qty(pr.optDouble("price", 0)));
            info.setText("Quedan " + qty(stock(pid[0])) + " · costo " + money(avgCost(pid[0])) + " c/u");
        };
        prodF.setOnClickListener(v -> pickProduct(idS -> { pid[0] = Integer.parseInt(idS); setProd.run(); }));
        setProd.run();
        Runnable calc = () -> {
            if (product(pid[0]) == null) { preview.setText(""); return; }
            double qq = num(q.getText().toString()), pv = num(price.getText().toString()), ac = avgCost(pid[0]);
            if (qq > 0) preview.setText("Total " + money(qq * pv) + " · Ganancia " + money(qq * (pv - ac)) + "\nCada socia: " + money(qq * (pv - ac) / 2));
        };
        watch(q, calc);
        watch(price, calc);
        calc.run();

        c.addView(label("🛍️", "Producto", true));
        c.addView(prodF);
        c.addView(info);
        c.addView(twoCols(labeled("Cantidad", q), labeled("Precio c/u (" + cur() + ")", price)));
        c.addView(preview);
        c.addView(label("💵", "¿Ya pagó?", false));
        LinearLayout pr = hbox();
        final TextView pa = chip("✅ Pagado", true, null), fi = chip("🧾 Fiado (paga después)", false, null);
        pa.setOnClickListener(v -> { paid[0] = true; styleChip(pa, true); styleChip(fi, false); });
        fi.setOnClickListener(v -> { paid[0] = false; styleChip(pa, false); styleChip(fi, true); });
        pr.addView(pa);
        pr.addView(fi);
        c.addView(hscroll(pr));
        c.addView(label("💳", "Forma de pago", false));
        LinearLayout mr = hbox();
        final TextView[] mc = new TextView[METHODS.length];
        for (int i = 0; i < METHODS.length; i++) {
            final int j = i;
            mc[i] = chip(METHODS[i], i == 0, v -> { method[0] = METHODS[j]; for (int k = 0; k < mc.length; k++) styleChip(mc[k], k == j); });
            mr.addView(mc[i]);
        }
        c.addView(mr);
        c.addView(label("🙋", "Cliente", false));
        c.addView(client);
        c.addView(dateField(date));

        p.addView(button("💰  Guardar venta", GRN, v -> {
            JSONObject prd = product(pid[0]);
            if (prd == null) { toast("Elige el producto"); return; }
            double qq = num(q.getText().toString()), pv = num(price.getText().toString());
            if (qq <= 0) { toast("Escribe la cantidad"); return; }
            if (qq > stock(pid[0]) + 0.0001) { toast("Solo quedan " + qty(stock(pid[0])) + ". Registra primero una compra."); return; }
            if (!paid[0] && client.getText().toString().trim().isEmpty()) { toast("Para un fiado escribe el nombre del cliente"); return; }
            JSONObject o = new JSONObject();
            put(o, "id", nextId());
            put(o, "pid", pid[0]);
            put(o, "name", prd.optString("name"));
            put(o, "qty", qq);
            put(o, "price", pv);
            put(o, "cost", avgCost(pid[0]));
            put(o, "paid", paid[0]);
            put(o, "by", by[0]);
            put(o, "method", method[0]);
            put(o, "client", client.getText().toString().trim());
            put(o, "date", date[0]);
            if (paid[0]) put(o, "paidAt", date[0]);
            sales.add(o);
            saveAll();
            toast("Venta guardada 💰 quedan " + qty(stock(pid[0])));
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    void salesScreen() {
        double pend = 0;
        int nPend = 0;
        for (JSONObject s : sales) if (!s.optBoolean("paid")) { pend += saleTotal(s); nPend++; }
        setHeader("Ventas", sales.size() + " ventas · " + money(pend) + " por cobrar", "💰", false);
        LinearLayout p = vbox();
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(8), dp(10), 0);
        for (String o : new String[]{"Todas", "Fiadas (" + nPend + ")"}) {
            final String key = o.startsWith("Fiadas") ? "Fiadas" : "Todas";
            chips.addView(chip(o, key.equals(salesFilter), v -> { salesFilter = key; salesScreen(); }));
        }
        p.addView(hscroll(chips));
        List<JSONObject> l = new ArrayList<>();
        for (JSONObject s : sales) if (salesFilter.equals("Todas") || !s.optBoolean("paid")) l.add(s);
        Collections.sort(l, (x, y) -> Long.compare(y.optLong("date"), x.optLong("date")));
        if (l.isEmpty()) p.addView(empty(salesFilter.equals("Todas") ? "Todavía no hay ventas" : "No hay fiados pendientes 🎉"));
        String last = "";
        for (int i = 0; i < l.size() && i < 400; i++) {
            JSONObject s = l.get(i);
            String d = dayStr(s.optLong("date"));
            if (!d.equals(last)) { last = d; p.addView(sectionTitle(d, null, null)); }
            p.addView(saleRow(s, true));
        }
        show(scroll(p), true, "＋  Venta", () -> open(() -> saleForm(-1)));
    }

    View saleRow(JSONObject s, boolean showName) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        boolean paid = s.optBoolean("paid");
        TextView ic = tv(paid ? "💰" : "🧾", 20, TXT, false);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(round(paid ? 0xFFE3F6E8 : 0xFFFFEDD5, 12));
        c.addView(ic, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout r = vbox();
        r.setPadding(dp(12), 0, dp(6), 0);
        JSONObject pr = product(s.optInt("pid"));
        String name = pr != null ? pr.optString("name") : s.optString("name");
        r.addView(tv((showName ? name + " · " : "Venta · ") + qty(s.optDouble("qty", 0)) + " × " + money(s.optDouble("price", 0)), 15, TXT, true));
        r.addView(tv(join(" · ", showName ? timeStr(s.optLong("date")) : dateStr(s.optLong("date")), s.optString("method"), s.optString("client")), 13, MUT, false));
        if (!paid) {
            TextView f = tv("🧾 Fiado · toca para cobrar", 12, ORG, true);
            f.setPadding(0, dp(3), 0, 0);
            r.addView(f);
        }
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout g = vbox();
        g.setGravity(Gravity.END);
        g.addView(tv(money(saleTotal(s)), 15, TXT, true));
        g.addView(tv("+" + money(saleProfit(s)), 12, GRN, true));
        c.addView(g);
        c.setOnClickListener(v -> saleMenu(s));
        c.setOnLongClickListener(v -> { saleMenu(s); return true; });
        return c;
    }

    void saleMenu(JSONObject s) {
        boolean paid = s.optBoolean("paid");
        List<String> opts = new ArrayList<>();
        if (!paid) opts.add("✅ Marcar como cobrado");
        if (!s.optString("client").isEmpty() && !paid) opts.add("💬 Recordarle el pago por WhatsApp");
        opts.add("🗑️ Eliminar venta (vuelve al inventario)");
        new AlertDialog.Builder(this)
                .setTitle(s.optString("name") + " · " + money(saleTotal(s)))
                .setItems(opts.toArray(new String[0]), (dlg, w) -> {
                    String o = opts.get(w);
                    if (o.startsWith("✅")) {
                        put(s, "paid", true);
                        put(s, "paidAt", System.currentTimeMillis());
                        saveAll();
                        toast("Cobrado ✅");
                        refresh();
                    } else if (o.startsWith("💬")) {
                        String msg = "Hola " + s.optString("client") + ", te recuerdo el pago pendiente de " + s.optString("name")
                                + " por " + money(saleTotal(s)) + ". ¡Gracias! 😊";
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(msg)));
                        launch(i);
                    } else {
                        confirmDelete("esta venta", () -> sales.remove(s));
                    }
                }).show();
    }

    // ============================ Socias y gastos ============================
    void partnersScreen() {
        setHeader("Socias 50 / 50", partner("1") + " y " + partner("2"), "🤝", false);
        LinearLayout p = vbox();
        double inv = 0, exp = 0, gp = 0, coll = 0, pend = 0, rev = 0;
        for (JSONObject x : purchases) inv += x.optDouble("qty", 0) * x.optDouble("cost", 0);
        for (JSONObject e : expenses) exp += e.optDouble("amount", 0);
        for (JSONObject s2 : sales) {
            gp += saleProfit(s2);
            rev += saleTotal(s2);
            if (s2.optBoolean("paid")) coll += saleTotal(s2); else pend += saleTotal(s2);
        }
        double profit = gp - exp, putIn = inv + exp;

        LinearLayout big = card();
        big.setBackground(round(PRI, 18));
        big.addView(tv("Ganancia total del negocio", 14, 0xFFCCFBF1, true));
        big.addView(tv(money(profit), 30, Color.WHITE, true));
        LinearLayout split = hbox();
        split.setPadding(0, dp(8), 0, 0);
        split.addView(halfBox(partner("1"), money(profit / 2)), weightLp(1f));
        split.addView(halfBox(partner("2"), money(profit / 2)), weightLp(1f));
        big.addView(split);
        p.addView(big);

        p.addView(sectionTitle("💵 Inversión", null, null));
        LinearLayout ic = card();
        ic.addView(kv("Invertido en mercancía", money(inv)));
        ic.addView(kv("Gastos", money(exp)));
        ic.addView(kv("Total puesto en el negocio", money(putIn)));
        ic.addView(divider());
        ic.addView(kv(partner("1") + " puso", money(putIn / 2), BLU));
        ic.addView(kv(partner("2") + " puso", money(putIn / 2), BLU));
        p.addView(ic);

        p.addView(sectionTitle("📈 ¿Cómo vamos?", null, null));
        LinearLayout rc = card();
        rc.addView(kv("Total vendido", money(rev)));
        rc.addView(kv("Ya cobrado", money(coll), GRN));
        rc.addView(kv("Por cobrar (fiados)", money(pend), ORG));
        rc.addView(divider());
        TextView st;
        if (coll >= putIn && putIn > 0)
            st = tv("✅ Ya recuperaron la inversión. Van " + money(coll - putIn) + " por encima (" + money((coll - putIn) / 2) + " cada una).", 15, GRN, true);
        else if (putIn > 0)
            st = tv("⏳ Faltan " + money(putIn - coll) + " por cobrar para recuperar la inversión (" + money((putIn - coll) / 2) + " cada una).", 15, ORG, true);
        else st = tv("Registra la primera compra para empezar.", 15, MUT, false);
        rc.addView(st);
        p.addView(rc);

        p.addView(sectionTitle("👥 A cada una le toca", null, null));
        LinearLayout pc = card();
        for (String w : new String[]{"1", "2"}) {
            pc.addView(tv("👤 " + partner(w), 16, TXT, true));
            pc.addView(kv("Puso", money(putIn / 2)));
            pc.addView(kv("Ganancia", money(profit / 2), GRN));
            pc.addView(kv("Del dinero ya cobrado", money(coll / 2)));
            if (w.equals("1")) pc.addView(divider());
        }
        p.addView(pc);

        p.addView(sectionTitle("💸 Gastos del negocio", "＋ Gasto", v -> open(this::expenseForm)));
        List<JSONObject> ex2 = new ArrayList<>(expenses);
        Collections.sort(ex2, (x, y) -> Long.compare(y.optLong("date"), x.optLong("date")));
        if (ex2.isEmpty()) p.addView(empty("Sin gastos (transporte, bolsas, envíos…)"));
        for (int i = 0; i < ex2.size() && i < 100; i++) {
            final JSONObject e = ex2.get(i);
            LinearLayout r = card();
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout t = vbox();
            t.addView(tv("💸 " + e.optString("concept"), 15, TXT, true));
            t.addView(tv(dateStr(e.optLong("date")) + " · cada una " + money(e.optDouble("amount", 0) / 2), 13, MUT, false));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(tv("−" + money(e.optDouble("amount", 0)), 15, RED, true));
            r.setOnLongClickListener(v -> { confirmDelete("este gasto", () -> expenses.remove(e)); return true; });
            p.addView(r);
        }
        if (!ex2.isEmpty()) {
            TextView hint = tv("Mantén presionado un gasto para eliminarlo.", 12, MUT, false);
            hint.setPadding(dp(18), dp(8), dp(18), 0);
            p.addView(hint);
        }
        show(scroll(p), true, "＋  Gasto", () -> open(this::expenseForm));
    }

    void transferDialog(String from, String to, double amt) {
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText a = input("Monto", DEC);
        a.setText(qty(amt));
        EditText n = input("Nota (opcional)", TXT_CAP);
        box.addView(a);
        box.addView(n);
        new AlertDialog.Builder(this)
                .setTitle(partner(from) + " le paga a " + partner(to))
                .setView(box)
                .setPositiveButton("Guardar", (dlg, w) -> {
                    double m = num(a.getText().toString());
                    if (m <= 0) { toast("Escribe el monto"); return; }
                    JSONObject o = new JSONObject();
                    put(o, "id", nextId());
                    put(o, "from", from);
                    put(o, "to", to);
                    put(o, "amount", m);
                    put(o, "note", n.getText().toString().trim());
                    put(o, "date", System.currentTimeMillis());
                    transfers.add(o);
                    saveAll();
                    refresh();
                }).setNegativeButton("Cancelar", null).show();
    }

    void expenseForm() {
        setHeader("Nuevo gasto", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);
        EditText concept = input("Ej. Transporte, bolsas, envío", TXT_CAP);
        EditText amount = input("Monto", DEC);
        final String[] by = {"1"};
        final long[] date = {System.currentTimeMillis()};
        c.addView(label("💸", "Concepto", true));
        c.addView(concept);
        LinearLayout qc = hbox();
        for (String k : new String[]{"Transporte", "Bolsas / empaque", "Envío", "Publicidad"}) qc.addView(chip(k, false, v -> concept.setText(k)));
        c.addView(hscroll(qc));
        c.addView(label("💵", "Monto (" + cur() + ")", true));
        c.addView(amount);
        c.addView(dateField(date));
        TextView t = tv("Los gastos se restan de la ganancia y se reparten entre las dos.", 13, MUT, false);
        t.setPadding(0, dp(10), 0, 0);
        c.addView(t);
        p.addView(button("Guardar gasto", ORG, v -> {
            String cn = concept.getText().toString().trim();
            double m = num(amount.getText().toString());
            if (cn.isEmpty() || m <= 0) { toast("Escribe el concepto y el monto"); return; }
            JSONObject o = new JSONObject();
            put(o, "id", nextId());
            put(o, "concept", cn);
            put(o, "amount", m);
            put(o, "by", by[0]);
            put(o, "date", date[0]);
            expenses.add(o);
            saveAll();
            toast("Gasto guardado");
            goBack();
        }));
        show(scroll(p), false, null, null);
    }

    void confirmDelete(String what, Runnable action) {
        new AlertDialog.Builder(this).setTitle("¿Eliminar " + what + "?")
                .setPositiveButton("Eliminar", (dlg, w) -> { action.run(); saveAll(); toast("Eliminado"); refresh(); })
                .setNegativeButton("Cancelar", null).show();
    }

    // ============================ Más ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("📲", "Compartir catálogo", "Lista de productos disponibles con precios", v -> shareCatalog()));
        c.addView(divider());
        c.addView(menuRow("📊", "Exportar a Excel", "Productos, compras, ventas, gastos y resumen", v -> exportXlsx()));
        c.addView(divider());
        c.addView(menuRow("⚙️", "Ajustes", "Nombre del negocio, socias y moneda", v -> open(() -> settings(false))));
        c.addView(divider());
        c.addView(menuRow("💾", "Copia de seguridad", "Guardar, enviar o restaurar tus datos", v -> Backup.menu(this)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Mi Negocio · versión 1.2", null));
        p.addView(c);
        show(scroll(p), true, null, null);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void settings(boolean first) {
        setHeader(first ? "¡Bienvenida!" : "Ajustes", first ? "Configura tu negocio" : null, first ? "🛍️" : null, !first);
        LinearLayout p = vbox();
        LinearLayout c = card();
        EditText biz = input("Ej. Tienda D&M", TXT_CAP);
        EditText p1 = input("Socia 1", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText p2 = input("Socia 2", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText curF = input("Ej. $, CUP, USD", InputType.TYPE_CLASS_TEXT);
        biz.setText(biz());
        p1.setText(pref("p1", "Daylin"));
        p2.setText(pref("p2", ""));
        curF.setText(cur());
        if (first) c.addView(tv("Solo toma un momento. Después lo puedes cambiar en Más → Ajustes.", 14, MUT, false));
        c.addView(label("🛍️", "Nombre del negocio", true));
        c.addView(biz);
        c.addView(twoCols(labeled("Socia 1", p1), labeled("Socia 2", p2)));
        c.addView(label("💱", "Moneda (símbolo)", false));
        c.addView(curF);
        LinearLayout cr = hbox();
        for (String k : new String[]{"$", "CUP ", "USD ", "€"}) cr.addView(chip(k.trim(), false, v -> curF.setText(k)));
        c.addView(hscroll(cr));
        p.addView(c);
        p.addView(button(first ? "Empezar" : "Guardar", PRI2, v -> {
            String a = p1.getText().toString().trim(), b = p2.getText().toString().trim();
            if (a.isEmpty() || b.isEmpty()) { toast("Escribe el nombre de las dos socias"); return; }
            setPref("biz", biz.getText().toString().trim().isEmpty() ? "Mi Negocio" : biz.getText().toString().trim());
            setPref("p1", a);
            setPref("p2", b);
            setPref("cur", curF.getText().toString().isEmpty() ? "$" : curF.getText().toString());
            sp().edit().putBoolean("setup", true).apply();
            toast("Guardado ✅");
            openTab(0);
        }));
        show(scroll(p), !first, null, null);
    }

    void shareCatalog() {
        List<JSONObject> l = new ArrayList<>();
        for (JSONObject pr : products) if (stock(pr.optInt("id")) > 0) l.add(pr);
        if (l.isEmpty()) { toast("No hay productos disponibles"); return; }
        Collections.sort(l, (a, b) -> (a.optString("cat") + a.optString("name")).compareToIgnoreCase(b.optString("cat") + b.optString("name")));
        StringBuilder t = new StringBuilder("🛍️ *" + biz() + "*\nProductos disponibles:\n");
        String lastCat = null;
        for (JSONObject pr : l) {
            String cat = pr.optString("cat");
            if (!cat.isEmpty() && !cat.equals(lastCat)) { t.append("\n*").append(cat).append("*\n"); lastCat = cat; }
            t.append("• ").append(pr.optString("name")).append(" — ").append(money(pr.optDouble("price", 0))).append("\n");
        }
        t.append("\n¡Escríbenos para apartar el tuyo! 😊");
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, t.toString());
        launch(Intent.createChooser(i, "Compartir catálogo"));
    }

    // ============================ Fotos ============================
    void photoMenu(int pid) {
        new AlertDialog.Builder(this).setTitle("Foto del producto")
                .setItems(new String[]{"📷 Tomar foto", "🖼️ Elegir de la galería", "🗑️ Quitar foto"}, (dlg, w) -> {
                    pendingProduct = pid;
                    if (w == 0) takePhoto();
                    else if (w == 1) {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("image/*");
                        try { startActivityForResult(i, REQ_PICK); } catch (Exception e) { toast("No se pudo abrir la galería"); }
                    } else {
                        JSONObject pr = product(pid);
                        if (pr != null) { put(pr, "photo", ""); saveAll(); refresh(); }
                    }
                }).show();
    }

    void takePhoto() {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a intentarlo");
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "producto_" + System.currentTimeMillis() + ".jpg");
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Mi Negocio");
        Uri u = null;
        try { u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv); } catch (Exception e) { }
        if (u == null) { toast("No se pudo preparar la cámara"); return; }
        pendingUri = u;
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, u);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHOTO); } catch (Exception e) { toast("No hay app de cámara"); }
    }

    void loadThumb(ImageView iv, Uri u) {
        new Thread(() -> {
            Bitmap b = null;
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
                int s = 1;
                while (o.outWidth / (s * 2) >= 240 && o.outHeight / (s * 2) >= 240) s *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = s;
                try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
                int rot = 0;
                try (InputStream in = getContentResolver().openInputStream(u)) {
                    int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    rot = ori == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : ori == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : ori == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
                } catch (Exception e) { }
                if (b != null && rot != 0) {
                    Matrix mx = new Matrix();
                    mx.postRotate(rot);
                    b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), mx, true);
                }
            } catch (Exception e) { b = null; }
            final Bitmap fb = b;
            runOnUiThread(() -> { if (fb != null) iv.setImageBitmap(fb); });
        }).start();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (Backup.onResult(this, rq, rs, data, this::afterRestore)) return;
        if (rq == REQ_EXPORT) {
            if (rs == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    writeXlsx(os);
                    toast("Excel guardado ✅");
                } catch (Exception e) { toast("No se pudo guardar el archivo"); }
            }
            return;
        }
        JSONObject pr = product(pendingProduct);
        if (rq == REQ_PHOTO) {
            if (rs == RESULT_OK && pr != null && pendingUri != null) put(pr, "photo", pendingUri.toString());
            else if (pendingUri != null) try { getContentResolver().delete(pendingUri, null, null); } catch (Exception e) { }
            pendingUri = null;
        } else if (rq == REQ_PICK && rs == RESULT_OK && data != null && data.getData() != null && pr != null) {
            try { getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
            put(pr, "photo", data.getData().toString());
        }
        saveAll();
        refresh();
    }

    // ============================ Excel ============================
    void exportXlsx() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE, biz().replaceAll("[^A-Za-z0-9]+", "_") + "_" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".xlsx");
        try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
    }

    void writeXlsx(OutputStream os) throws Exception {
        List<String> names = new ArrayList<>();
        List<List<List<Object>>> sheets = new ArrayList<>();
        List<int[]> widths = new ArrayList<>();

        List<List<Object>> pr = new ArrayList<>();
        pr.add(row("Producto", "Categoría", "Comprados", "Vendidos", "Quedan", "Costo promedio", "Precio de venta",
                "Ganancia por unidad", "Total vendido", "Ganancia obtenida", "Ganancia si se vende lo que queda"));
        List<JSONObject> ps = new ArrayList<>(products);
        Collections.sort(ps, (a, b) -> a.optString("name").compareToIgnoreCase(b.optString("name")));
        for (JSONObject p : ps) {
            int id = p.optInt("id");
            double ac = avgCost(id), price = p.optDouble("price", 0), st = stock(id);
            pr.add(row(p.optString("name"), p.optString("cat"), bought(id), sold(id), st, r2(ac), r2(price), r2(price - ac),
                    r2(soldAmount(id)), r2(soldProfit(id)), r2(Math.max(0, st) * (price - ac))));
        }
        names.add("Productos"); sheets.add(pr); widths.add(new int[]{30, 16, 11, 10, 9, 14, 14, 14, 13, 15, 18});

        List<List<Object>> cp = new ArrayList<>();
        cp.add(row("Fecha", "Producto", "Cantidad", "Costo c/u", "Total", "Cada socia", "Proveedor"));
        for (JSONObject x : sortedByDate(purchases)) {
            JSONObject p = product(x.optInt("pid"));
            cp.add(row(xlDate(x.optLong("date")), p == null ? "" : p.optString("name"), x.optDouble("qty", 0), r2(x.optDouble("cost", 0)),
                    r2(x.optDouble("qty", 0) * x.optDouble("cost", 0)), r2(x.optDouble("qty", 0) * x.optDouble("cost", 0) / 2), x.optString("supplier")));
        }
        names.add("Compras"); sheets.add(cp); widths.add(new int[]{17, 30, 10, 11, 11, 14, 20});

        List<List<Object>> vt = new ArrayList<>();
        vt.add(row("Fecha", "Producto", "Cantidad", "Precio c/u", "Total", "Costo c/u", "Ganancia", "Ganancia c/socia", "Estado", "Forma de pago", "Cliente"));
        for (JSONObject s : sortedByDate(sales)) {
            vt.add(row(xlDate(s.optLong("date")), s.optString("name"), s.optDouble("qty", 0), r2(s.optDouble("price", 0)), r2(saleTotal(s)),
                    r2(s.optDouble("cost", 0)), r2(saleProfit(s)), r2(saleProfit(s) / 2), s.optBoolean("paid") ? "Pagado" : "Fiado",
                    s.optString("method"), s.optString("client")));
        }
        names.add("Ventas"); sheets.add(vt); widths.add(new int[]{17, 30, 10, 11, 11, 11, 11, 15, 9, 14, 20});

        List<List<Object>> gs = new ArrayList<>();
        gs.add(row("Fecha", "Concepto", "Monto", "Cada socia"));
        for (JSONObject e : sortedByDate(expenses))
            gs.add(row(xlDate(e.optLong("date")), e.optString("concept"), r2(e.optDouble("amount", 0)), r2(e.optDouble("amount", 0) / 2)));
        names.add("Gastos"); sheets.add(gs); widths.add(new int[]{17, 30, 12, 14});

        double rev = 0, gp = 0, ex = 0, pend = 0;
        for (JSONObject s : sales) { rev += saleTotal(s); gp += saleProfit(s); if (!s.optBoolean("paid")) pend += saleTotal(s); }
        for (JSONObject e : expenses) ex += e.optDouble("amount", 0);
        List<List<Object>> rs = new ArrayList<>();
        rs.add(row("Concepto", "Monto"));
        rs.add(row("Total vendido", r2(rev)));
        rs.add(row("Ganancia de las ventas", r2(gp)));
        rs.add(row("Gastos", r2(ex)));
        rs.add(row("Ganancia neta", r2(gp - ex)));
        rs.add(row("Le corresponde a " + partner("1"), r2((gp - ex) / 2)));
        rs.add(row("Le corresponde a " + partner("2"), r2((gp - ex) / 2)));
        rs.add(row("Por cobrar (fiados)", r2(pend)));
        double inv = 0, coll = 0;
        for (JSONObject x : purchases) inv += x.optDouble("qty", 0) * x.optDouble("cost", 0);
        for (JSONObject s2 : sales) if (s2.optBoolean("paid")) coll += saleTotal(s2);
        rs.add(row("Invertido en mercancía", r2(inv)));
        rs.add(row("Total puesto (mercancía + gastos)", r2(inv + ex)));
        rs.add(row(partner("1") + " puso", r2((inv + ex) / 2)));
        rs.add(row(partner("2") + " puso", r2((inv + ex) / 2)));
        rs.add(row("Ya cobrado", r2(coll)));
        names.add(0, "Resumen"); sheets.add(0, rs); widths.add(0, new int[]{36, 16});

        ZipOutputStream z = new ZipOutputStream(os);
        String ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        String pk = "http://schemas.openxmlformats.org/package/2006/relationships";
        String hd = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
        StringBuilder ct = new StringBuilder(hd + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder wb = new StringBuilder(hd + "<workbook xmlns=\"" + ns + "\" xmlns:r=\"" + rel + "\"><sheets>");
        StringBuilder wr = new StringBuilder(hd + "<Relationships xmlns=\"" + pk + "\">");
        for (int i = 0; i < names.size(); i++) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                    .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            wb.append("<sheet name=\"").append(xml(names.get(i))).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            wr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(rel).append("/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
        }
        ct.append("</Types>");
        wb.append("</sheets></workbook>");
        wr.append("<Relationship Id=\"rId").append(names.size() + 1).append("\" Type=\"").append(rel).append("/styles\" Target=\"styles.xml\"/></Relationships>");
        zput(z, "[Content_Types].xml", ct.toString());
        zput(z, "_rels/.rels", hd + "<Relationships xmlns=\"" + pk + "\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        zput(z, "xl/workbook.xml", wb.toString());
        zput(z, "xl/_rels/workbook.xml.rels", wr.toString());
        zput(z, "xl/styles.xml", hd + "<styleSheet xmlns=\"" + ns + "\">"
                + "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"#,##0.00\"/></numFmts>"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0F766E\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>"
                + "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        for (int i = 0; i < names.size(); i++) zput(z, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(ns, sheets.get(i), widths.get(i)));
        z.finish();
    }

    static double r2(double v) { return Math.round(v * 100) / 100.0; }

    List<JSONObject> sortedByDate(List<JSONObject> l) {
        List<JSONObject> r = new ArrayList<>(l);
        Collections.sort(r, (x, y) -> Long.compare(x.optLong("date"), y.optLong("date")));
        return r;
    }

    static String xlDate(long ms) { return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(ms)); }

    static List<Object> row(Object... cells) {
        List<Object> r = new ArrayList<>();
        Collections.addAll(r, cells);
        return r;
    }

    static void zput(ZipOutputStream z, String name, String content) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static String colName(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    static String xml(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t' && ch != '\r') b.append(' ');
            else b.append(ch);
        }
        return b.toString();
    }

    static String sheetXml(String ns, List<List<Object>> rows, int[] widths) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        s.append("<worksheet xmlns=\"").append(ns).append("\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols>");
        for (int i = 0; i < widths.length; i++)
            s.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            s.append("<row r=\"").append(r + 1).append("\">");
            List<Object> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                Object v = row.get(c);
                String ref = colName(c) + (r + 1);
                if (v instanceof Number && r > 0) {
                    double d = ((Number) v).doubleValue();
                    boolean whole = Math.abs(d - Math.round(d)) < 1e-9;
                    s.append("<c r=\"").append(ref).append("\"").append(whole ? "" : " s=\"2\"").append("><v>")
                            .append(whole ? String.valueOf(Math.round(d)) : String.valueOf(d)).append("</v></c>");
                } else {
                    String str = v == null ? "" : v.toString();
                    if (str.isEmpty() && r > 0) continue;
                    s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(r == 0 ? " s=\"1\"" : "")
                            .append("><is><t xml:space=\"preserve\">").append(xml(str)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    // ============================ Utilidades ============================
    View dateField(long[] date) {
        final TextView f = field("📅  " + dateStr(date[0]));
        f.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(date[0]);
            new DatePickerDialog(this, (dpk, y, m, d) -> {
                Calendar n = Calendar.getInstance();
                n.setTimeInMillis(date[0]);
                n.set(y, m, d);
                date[0] = n.getTimeInMillis();
                f.setText("📅  " + dateStr(date[0]));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        return labeled("Fecha", f);
    }

    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }
    static String dateStr(long ms) { return cap(new SimpleDateFormat("EEE d MMM yyyy", ES).format(new Date(ms))); }
    static String timeStr(long ms) { return new SimpleDateFormat("h:mm a", Locale.US).format(new Date(ms)); }

    static String dayStr(long ms) {
        Calendar a = Calendar.getInstance(), b = Calendar.getInstance();
        b.setTimeInMillis(ms);
        if (a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)) return "Hoy";
        a.add(Calendar.DAY_OF_YEAR, -1);
        if (a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)) return "Ayer";
        return cap(new SimpleDateFormat("EEEE d MMM yyyy", ES).format(new Date(ms)));
    }

    static String join(String sep, String... parts) {
        StringBuilder b = new StringBuilder();
        for (String p : parts) {
            if (p == null || p.trim().isEmpty()) continue;
            if (b.length() > 0) b.append(sep);
            b.append(p.trim());
        }
        return b.toString();
    }

    LinearLayout.LayoutParams weightLp(float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, w);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    TextView button2(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(8), dp(14), dp(8), dp(14));
        b.setOnClickListener(l);
        return b;
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    static void put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception e) { }
    }

    void afterRestore() {
        recreate();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

}
