# Mi Negocio — Android v1.0

Inventario y ventas para un negocio entre dos socias: productos, compras (lotes), ventas al contado o fiadas,
gastos, ganancia repartida 50/50, cuentas entre socias, catálogo para WhatsApp y exportación a Excel.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
